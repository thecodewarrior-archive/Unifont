package com.google.typography.font.sfntly.table.opentype.component;

public interface LookupType {
  int typeNum();
}
