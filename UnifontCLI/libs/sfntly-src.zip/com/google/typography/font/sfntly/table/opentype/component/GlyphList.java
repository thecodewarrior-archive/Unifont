package com.google.typography.font.sfntly.table.opentype.component;

import java.util.ArrayList;

class GlyphList extends ArrayList<Integer> {
  private static final long serialVersionUID = 4699092062720505377L;

  GlyphList() {
    super();
  }
}
